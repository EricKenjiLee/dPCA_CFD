function resampledBlocks = resampleVaryingBlocks(R1, R2, R3, R4, G1, G2, G3, G4)
% RESAMPLEVARYINGBLOCKS Concatenates, shuffles, and splits the input 
% matrices back into equally sized, randomized blocks, where the size 
% of each new block matches the size of its original input matrix.
%
%   RESAMPLEDBLOCKS = resampleVaryingBlocks(R1, R2, R3, R4, G1, G2, G3, G4)
%
%   Inputs:
%       R1, R2, ..., G4: The original component matrices.
%                        ASSUMPTION: All input matrices must have the same 
%                        number of columns (variables).
%
%   Output:
%       RESAMPLEDBLOCKS: A cell array containing the 8 new, resampled blocks 
%                        (e.g., cell 1 is New R1, size(New R1) == size(R1)).

    % --- 1. Validation and Setup ---
    
    % Collect all input matrices into a cell array
    originalBlocks = {R1, R2, R3, R4, G1, G2, G3, G4};
    numBlocks = length(originalBlocks);
    
    % Store the row count and check for consistent column count (variables)
    originalRowCounts = zeros(numBlocks, 1);
    
    % Get the number of columns from the first matrix
    numColumns = size(R1, 2);
    
    for i = 1:numBlocks
        % Check for consistent column count across all blocks
        if size(originalBlocks{i}, 2) ~= numColumns
            error('All input matrices must have the same number of columns (variables).');
        end
        % Record the number of rows for each original block
        originalRowCounts(i) = size(originalBlocks{i}, 1);
    end
    
    % --- 2. Concatenate and Shuffle ---
    
    % Concatenate all blocks vertically to form bigMat
    bigMat = vertcat(originalBlocks{:});
    
    % Randomly shuffle the rows of bigMat
    totalRows = size(bigMat, 1);
    shuffledMat = bigMat(randperm(totalRows), :);

    % --- 3. Split into Resampled Blocks using Original Counts ---
    
    resampledBlocks = cell(numBlocks, 1);
    startIdx = 1;

    for i = 1:numBlocks
        % The size of the current block is based on the stored row count
        currentBlockRows = originalRowCounts(i);
        endIdx = startIdx + currentBlockRows - 1;
        
        % Extract the block from the shuffled matrix
        resampledBlocks{i} = shuffledMat(startIdx:endIdx, :);
        
        % Update the starting index for the next block
        startIdx = endIdx + 1;
    end
    
    % Display confirmation
    % fprintf('Processed %d original blocks. Total rows: %d. New randomized blocks created.\n', ...
            numBlocks, totalRows);
    % fprintf('The size of each new block matches its original counterpart.\n');
end