monkey = 'tiberius';
align = 'targets';

switch(monkey)
    case 'bilbo'
        sessData = returnSessionData_Bilbo();
    case 'tiberius'
        sessData = returnSessionData_Tibs();
end

switch(align)
    case 'checkerboard'
        pre = -0.4;
        post = 1.5;

    case 'targets'
        pre = -0.8;
        post = 0.4;
end


firingRatesAverage = [];
firingRatesAverageError = [];
firingRatesAverageCorrect = [];
firingRatesPooledError = [];

for m=1:length(sessData) %You can pass in listed savetags with sessData(m).savetags as the last argument instead of []
    currData = returnSessionFiringRatesPerCoherence(sessData(m),align,pre,post,'all',[],[]);
    firingRatesAverage = cat(1, firingRatesAverage, currData);

    currDataError = returnSessionFiringRatesPerCoherence(sessData(m),align,pre,post,'wrong',[],[]);
    firingRatesAverageError = cat(1, firingRatesAverageError, currDataError);

    allDataError = returnErrorFiringRates(sessData(m),align,pre,post,[],[]);
    firingRatesPooledError = cat(1, firingRatesPooledError, allDataError);

    currDataCorrect = returnSessionFiringRatesPerCoherence(sessData(m),align,pre,post,'correct',[],[]);
    firingRatesAverageCorrect = cat(1, firingRatesAverageCorrect, currDataCorrect);
end

%firingRatesAverage arranged as Neurons by Color by Coherence by Time
% Color: Red then Green; Coherence: Easy, Medium, Hard

preCut = pre + 0.2;
postCut = post-0.2;
%%
time = [preCut*1000:postCut*1000-1];
timeEvents = 0;

%%
figure(4);
clf;
Zcom = [];
ZerrorCom = [];
ZPooledE = [];
cols = {'ro','r.','r-','r--','go','g.','g-','g--'};
cnt = 1;

centeringSignal = nanmean(nanmean(firingRatesAverage,2),3);

Z = firingRatesAverage - repmat(centeringSignal,[1 size(firingRatesAverageCorrect,[2 3]) 1]);
Zerror = firingRatesAverageError - repmat(centeringSignal,[1 size(firingRatesAverageCorrect,[2 3]) 1]);
Zcorrect = firingRatesAverageCorrect - repmat(centeringSignal,[1 size(firingRatesAverageCorrect,[2 3]) 1]);
Zpooled = firingRatesPooledError - repmat(centeringSignal,[1 size(firingRatesPooledError,[2 3]) 1]);


%%
figure(1)
if 1
    currDataS = [];
    for n=1:size(firingRatesAverage,1)
        currDataS(n,:,:,:) = Zcorrect(n,randi(2,1,2),randi(4,1,4),:);
    end
else
    currDataS = Zcorrect;
end
combinedParams = {{1, [1 3]}, {2, [2 3]}, {3}, {[1 2], [1 2 3]}};
margNames = {'Category', 'Difficulty', 'Condition-independent', 'Category/Difficulty Interaction'};
margColours = [23 100 171; 187 20 25; 150 150 150; 114 97 171]/256;

tic
[W,V,whichMarg] = dpca(currDataS, 10, ...
    'combinedParams', combinedParams);
toc

explVar = dpca_explainedVariance(currDataS, W, V, ...
    'combinedParams', combinedParams);

[Zfull, componentsToPlot] = dpca_plot(currDataS, W, V, @dpca_plot_default, ...
    'explainedVar', explVar, ...
    'marginalizationNames', margNames, ...
    'marginalizationColours', margColours, ...
    'whichMarg', whichMarg,                 ...
    'time', time,                        ...
    'timeEvents', timeEvents,               ...
    'timeMarginalization', 3, ...
    'legendSubplot', 16);

%%
cols = {'ro','r.','r-','r--','go','g.','g-','g--'};
cnt = 1;
mSize = 9;

startV = 100;
endV = 800;
targets = 600;
for m = 1:size(Z,2)
    for n=1:size(Z,3)
        temp = W'*squeeze(Zcorrect(:,m,n,:)); % project onto dPC space

        Zcom(:,m,n,:) = temp;
        ZerrorCom(:,m,n,:) = W'*squeeze(Zerror(:,m,n,:));

        C1 = squeeze(Zcom(1,m,n,startV:endV));
        C2 = squeeze(Zcom(2,m,n,startV:endV));
        C3 = squeeze(Zcom(3,m,n,startV:endV));


        plot3(C1, C2, C3, cols{cnt});   hold on;
        plot3(C1(1), C2(1), C3(1), 'bd','markersize',mSize);
        plot3(C1(targets), C2(targets), C3(targets), 'bs','markersize',mSize);

     
         if m==1 & n==2
             ZPooledE(:,m,n,:) = W'*squeeze(Zpooled(:,m,n,:));
             C1 = squeeze(ZPooledE(1,m,n,startV:endV));
             C2 = squeeze(ZPooledE(2,m,n,startV:endV));
             C3 = squeeze(ZPooledE(3,m,n,startV:endV));

             plot3(C1, C2, C3, '-','LineWidth',3,'color',[0.4 0 0]);   hold on;
             plot3(C1(1), C2(1), C3(1), 'bd','markersize',mSize);
             plot3(C1(targets), C2(targets), C3(targets), 'bs','markersize',mSize);

         
         end

         if m==2 & n==2
             ZPooledE(:,m,n,:) = W'*squeeze(Zpooled(:,m,n,:));
             C1 = squeeze(ZPooledE(1,m,n,startV:endV));
             C2 = squeeze(ZPooledE(2,m,n,startV:endV));
             C3 = squeeze(ZPooledE(3,m,n,startV:endV));
             
             plot3(C1, C2, C3, '-','LineWidth',3,'color',[0 0.4 0]);   hold on;
             plot3(C1(1), C2(1), C3(1), 'bd','markersize',mSize);
             plot3(C1(targets), C2(targets), C3(targets), 'bs','markersize',mSize);

     

         end


        cnt = cnt + 1;
    end

end
xline(0);
yline(0);

title('bilbo!')


%%
D = preprocessAll(firingRatesAverage, firingRatesAverageCorrect, firingRatesAverageError);
%%

test = D.processedFR';
[coeff, score, latent] = pca(test);

m = size(firingRatesAverage,2)*size(firingRatesAverage,3);
t = size(firingRatesAverage,4);



%%
scoreError = D.processedFRerror'*coeff;
scoreCorrect = D.processedFRcorrect'*coeff;
%%
orthF = [];
orthFerror = [];
orthFcorrect = [];

for thi = 1 : m
    orthF(:,:,thi) = (score( (1:t) + (thi-1)*t, :))';
    orthFerror(:,:,thi) = (scoreError( (1:t) + (thi-1)*t, :))';
    orthFcorrect(:,:,thi) = (scoreCorrect( (1:t) + (thi-1)*t, :))';
end



%%
figure(2);

coh_to_use = [1 2 3 4 5 6 7 8];
correct_colsR = [1 0 0 0.9; .8 0 0 0.7; .8 0 0 0.5; .8 0 0 0.2];
correct_colsG = [0 1 0 0.9; 0 0.85 0 0.8; 0 0.6  0 0.5; 0 0.5 0 0.2];
correct_cols = [correct_colsR; correct_colsG];
error_cols = {'ko','k.','k-','k--','ko','k.','k-','k--'};

tEvent = find(time > 0,1,'first');

for n=coh_to_use
    hold on;
    % plot3(squeeze(orthFcorrect(1, 1:tEvent, n)),squeeze(orthFcorrect(2, 1:tEvent, n)),squeeze(orthFcorrect(3, 1:tEvent, n)), 'color',correct_cols(n,:),'LineWidth',3)
    hold on

    % plot3(squeeze(orthF(1, 1:tEvent, n)),squeeze(orthF(2, 1:tEvent, n)),squeeze(orthF(3, 1:tEvent, n)), 'color',correct_cols(n,:),'LineWidth',.5)
    hold on;
    if n <= 4
        mColor = 'r';
    else
        mColor = 'g';
    end
    % if  n == 4
    %     plot3(squeeze(orthFerror(1, 1:tEvent, n)),squeeze(orthFerror(2, 1:tEvent, n)), squeeze(orthFerror(3, 1:tEvent, n)), '--','LineWidth',2,'Color',[0.4 0.2 0]);
    % end
    %
    % if n== 8
    %     plot3(squeeze(orthFerror(1, 1:tEvent, n)),squeeze(orthFerror(2, 1:tEvent, n)), squeeze(orthFerror(3, 1:tEvent, n)), '--','LineWidth',2,'Color',[0.2 0.6 0]);
    % end

    plot(squeeze(orthFcorrect(1, tEvent, n)),squeeze(orthFcorrect(2, tEvent, n)), 'd','MarkerSize',mSize,...
        'MarkerFaceColor',[0.8 0.8 1],'Color',mColor);
    % plot3(squeeze(orthFcorrect(1, 1, n)),squeeze(orthFcorrect(2, 1, n)),squeeze(orthFcorrect(3, 1, n)), 's','MarkerSize',12,...
    %     'MarkerFaceColor',[0.8 0.8 1],'Color',mColor);
end
%%
plot(sum([squeeze(orthF(1:8,:,1)-orthF(1:8,:,3))].^2),'b-');
hold on;
plot(sum([squeeze(orthF(1:8,:,1)-orthF(1:8,:,2))].^2),'m-');
hold on;
%%
figure (3)

cols = {'ro','r.','r-','r--','go','g.','g-','g--'};

tEvent = find(time > 0,1,'first');
for n=1:length(cols)
    hold on;
    plot3(squeeze(orthF(1, 1:tEvent, n)),squeeze(orthF(2, 1:tEvent, n)),squeeze(orthF(3, 1:tEvent, n)), cols{n},'LineWidth',1)
    hold on;
    % if n==4
    %     plot3(squeeze(orthFerror(1, 1:tEvent, n)),squeeze(orthFerror(2, 1:tEvent, n)),squeeze(orthFerror(3, 1:tEvent, n)), 'm-','LineWidth',2)
    % end
    %
    % if n==8
    %     plot3(squeeze(orthFerror(1, 1:tEvent, n)),squeeze(orthFerror(2, 1:tEvent, n)),squeeze(orthFerror(3, 1:tEvent, n)), 'm--','LineWidth',2)
    % end

    hold on;
    if n <= 4
        mColor = 'r';
    else
        mColor = 'g';
    end
    plot3(squeeze(orthF(1, tEvent, n)),squeeze(orthF(2, tEvent, n)),squeeze(orthF(3, tEvent, n)), 'd','MarkerSize',12,...
        'MarkerFaceColor',[0.8 0.8 1],'Color',mColor);
    plot3(squeeze(orthF(1, 1, n)),squeeze(orthF(2, 1, n)),squeeze(orthF(3, 1, n)), 's','MarkerSize',12,...
        'MarkerFaceColor',[0.8 0.8 1],'Color',mColor);
end


%%
figure(4)
for ii = 1:4
    subplot(2,2,ii); hold on
    plot(time, squeeze(orthF(ii, :, 1)), 'ro')
    plot(time, squeeze(orthF(ii, :, 2)), 'r.')
    plot(time, squeeze(orthF(ii, :, 3)), 'r-')
    plot(time, squeeze(orthF(ii, :, 4)), 'r--')
    plot(time,squeeze(orthF(ii, :, 5)), 'go')
    plot(time,squeeze(orthF(ii, :, 6)), 'g.')
    plot(time, squeeze(orthF(ii, :, 7)), 'g-')
    plot(time, squeeze(orthF(ii, :, 8)), 'g--')
    title(['pc ' num2str(ii)]);
    d = xline(0);
    d.LineStyle = '--';
    d = yline(0);
    d.LineStyle = '--';
end

